<?php
session_start();
if($_POST['submitted']){

	if((!empty($_POST['uname']))&&(!empty($_POST['psw']))){
					   
		$dbc = mysqli_connect('localhost','root','');
		mysqli_select_db ($dbc, "delicates");
		$problem = FALSE;						
                        

		if((!empty($_POST['uname']))&&(!empty($_POST['psw']))){
			$username = trim($_POST['uname']);   
			$password = trim($_POST['psw']);   
			
			$sql = "SELECT * FROM tbl_user WHERE username = '$username' AND password = '$password' ";
			$result = $dbc->query($sql);
			if ($result ->num_rows > 0) {
                while($row = mysqli_fetch_assoc($result)) {
                    $_SESSION['user_id']=$row['user_id'];
                }
			}else {
				alert("Incorrect username or password entered! Please try again");
				echo'<meta http-equiv="refresh" content="2; url=index.php">';
			}
		} else {
			$problem = TRUE;
		}
						
		mysqli_close($dbc);
        echo'<meta http-equiv="refresh" content="2; url=index.php">';		
	}
}
?>
<?php
function alert($msg) {
    echo "<script type='text/javascript'>alert('$msg');</script>";
}
?>