<!-- Header -->
<?php
    if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 
?>
                <div class="header-area">
                <div class="main-header  header-sticky">
                    <div class="container-fluid">
                        <div class="row align-items-center">
                            <!-- Logo -->
                            <div class="col-xl-2 col-lg-2 col-md-1">
                                <div class="logo">
                                    <a href="index.php"><img src="assets/img/logo/mylogo.png" alt="" height="80" width="80" ></a>
                                </div>
                            </div>
                            <div class="col-xl-10 col-lg-10 col-md-10">
                                <div class="menu-main d-flex align-items-center justify-content-end">
                                    <!-- Main-menu -->
                                    <div class="main-menu f-right d-none d-lg-block">
                                        <nav> 
                                            <ul id="navigation">
                                                <li><a href="index.php">Home</a></li>
                                                <li><a href="about.php">About</a></li> 
                                                <li><a href="blog.php">Blog</a></li>
                                                <li><a href="contact.php">Contact</a></li>
                                                <?php
                                                    if(isset($_SESSION['user_id'])){
                                                        echo"<li><a href=\"logout.php\"><i class=\"fa fa-user\"></i> Log Out </a></li>";
                                                    }
                                                    else{
                                                        echo"<li><a href=\"#\" onclick=\"document.getElementById('id01').style.display='block'\"><i class=\"fa fa-user\"></i> Log In</a></li>";
                                                    }
                                                ?>
                                            </ul>
                                        </nav>
                                    </div>
                                </div>
                            </div>   
                            
                        </div>
                    </div>
                </div>
    </header>
  <!--Login Modal-->    
<!-- Modal: modalQuickView -->
    <div id="id01" class="modal">
  
  <form class="modal-content animate" style="width: 30%" action="login.php" method="post">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
      <img src="images/img_avatar2.png" alt="Avatar" class="avatar">
    </div>

    <div class="container">
      <label for="uname"><b>Username</b></label>
      <input type="text" placeholder="Enter Username" name="uname" required>

      <label for="psw"><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="psw" required> 
        <button type="submit" style="background: #550a43;">Login</button>
        <input type="hidden" name="submitted" value="1">
      <label>
        <input type="checkbox" checked="checked" name="remember"> Remember me
      </label>
    </div>

    <div class="container" style="background-color:#f1f1f1">
      <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn" style="background: #A10490;">Cancel</button>
        <span class="psw">Don't have an account? Sign up <a href="signup.php" style="color: blue">here</a></span>
    </div>
  </form>
  </div>