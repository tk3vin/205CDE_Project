<!DOCTYPE html>
<html lang="en">
<head>
<title>Delicates</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Sublime project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" type="text/css" href="styles/checkout.css">
 <link rel="stylesheet" type="text/css" href="styles/main_styles.css">
 <link rel="stylesheet" type="text/css" href="styles/responsive.css">
 <link rel="stylesheet" type="text/css" href="styles/header.css">
 <link rel="stylesheet" type="text/css" href="styles/login.css">
	<link rel="stylesheet" href="assets/css/themify-icons.css">
	<link rel="stylesheet" href="assets/css/slick.css">
	<link rel="stylesheet" href="assets/css/nice-select.css">
	<link rel="stylesheet" href="assets/css/style.css">
	<link rel="stylesheet" href="assets/css/magnific-popup.css">
</head>
<body>

<div class="super_container">

    <?php
            include 'header.php';
        ?>

    <!--signup form-->
			<div class="container" style="padding-top: 100px">
			<div class="row">

                <div class="col-lg-3">
                    </div>
				<!-- Billing Info -->
				<?php
                
				if(isset($_POST['submitted'])){

					if((!empty($_POST['checkout_name']))&&(!empty($_POST['signup_last_name']))&&
					   (!empty($_POST['signup_username']))&&(!empty($_POST['signup_psw']))&&
					   (!empty($_POST['signup_phone']))&&(!empty($_POST['signup_email']))){
					   

						$dbc = mysqli_connect('localhost','root','');
						mysqli_select_db ($dbc, "delicates");
						$problem = FALSE;
						
                        
						$fname = $_POST['checkout_name'];
						$lname = $_POST['signup_last_name'];
						$name = $fname . $lname;

						if((!empty($_POST['checkout_name']))&&(!empty($_POST['signup_last_name']))&&
					      (!empty($_POST['signup_username']))&&(!empty($_POST['signup_psw']))&&
					      (!empty($_POST['signup_phone']))&&(!empty($_POST['signup_email']))){
							$name = trim($name);
							$email = trim($_POST['signup_email']);   
							$phone = trim($_POST['signup_phone']);
							$username = trim($_POST['signup_username']);
							$password = trim($_POST['signup_psw']);
			
						} else {
							$problem = TRUE;
						}
						
						if (!$problem) {
						$query = "INSERT INTO tbl_user(name, email, phone, username, password) 
												   VALUES ('$name', '$email', '$phone', '$username',
														   '$password')";
					
							if (mysqli_query($dbc, $query)){
								alert("Sign Up Successful !");
							}	
							else {
								print ' <p style = "color:red;">Could not add the data because:<br />'.mysqli_connect_error($dbc).'.</p>
								<p>The query was: '.$query.'</p>';
							}
						}
						mysqli_close($dbc);
                        echo'<meta http-equiv="refresh" content="2; url=index.php">';
					   }
					else{
                            alert("Please fill in all required field!");
					}		
				}
				else{
				echo'
				<div class="col-lg-6">
					<div class="billing checkout_section"> 
						<div class="section_title">Sign Up Form</div>
						<div class="section_subtitle">Enter your sign up info</div>
					 	<div class="checkout_form_container">
							<form action="signup.php" method="POST" id="checkout_form" class="checkout_form">
								<div class="row">
									<div class="col-xl-6">
										<!-- Name -->
										<label for="signup_name">First Name*</label>
										<input type="text" name="checkout_name" class="checkout_input" required="required">
									</div>
									<div class="col-xl-6 last_name_col">
										<!-- Last Name -->
										<label for="signup_last_name">Last Name*</label>
										<input type="text" name="signup_last_name" class="checkout_input" required="required">
									</div>
								</div>
								<div>
									<!-- username -->
									<label for="signup_username">Username*</label>
									<input type="text" name="signup_username" class="checkout_input" required="required">
								</div>
                                <div>
									<!-- Password -->
									<label for="signup_password">Password*</label>
									<input type="password" name="signup_psw" class="checkout_input" required="required">
								</div>
                                <div>
									<!-- Phone no -->
									<label for="signup_phone">Phone no*</label>
									<input type="text" placeholder="XXX-XXX XXXX" name="signup_phone" class="checkout_input" required="required">
								</div>
                                <div>
									<!-- Email -->
									<label for="signup_email">Email Address*</label>
									<input type="text" name="signup_email" class="checkout_input" placeholder="example@mail.com" required="required">
								</div>
								<button type="submit" style="background: #550a43;">Submit</button>
								<input type="hidden" name="submitted" value="true">
							</form> 
											
						</div>
					</div>
				</div>
			</div>
		</div>
		<hr>';
                    }
				?>
    
</div>
<?php
function alert($msg) {
    echo "<script type='text/javascript'>alert('$msg');</script>";
}
?>
<script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap4/popper.js"></script>
<script src="styles/bootstrap4/bootstrap.min.js"></script>
<script src="plugins/greensock/TweenMax.min.js"></script>
<script src="plugins/greensock/TimelineMax.min.js"></script>
<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="plugins/greensock/animation.gsap.min.js"></script>
<script src="plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="plugins/Isotope/isotope.pkgd.min.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="plugins/parallax-js-master/parallax.min.js"></script>
<script src="js/custom.js"></script>
</body>
</html>