<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title> Delicates</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="manifest" href="site.webmanifest">

	<!-- CSS here -->
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/css/owl.carousel.min.css">
	<link rel="stylesheet" href="assets/css/slicknav.css">
    <link rel="stylesheet" href="assets/css/flaticon.css">
    <link rel="stylesheet" href="assets/css/gijgo.css">
	<link rel="stylesheet" href="assets/css/animate.min.css">
	<link rel="stylesheet" href="assets/css/magnific-popup.css">
	<link rel="stylesheet" href="assets/css/fontawesome-all.min.css">
	<link rel="stylesheet" href="assets/css/themify-icons.css">
	<link rel="stylesheet" href="assets/css/slick.css">
	<link rel="stylesheet" href="assets/css/nice-select.css">
	<link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
    <link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
    <link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
    <link rel="stylesheet" type="text/css" href="styles/main_styles.css">
    <link rel="stylesheet" type="text/css" href="styles/responsive.css">
    <link rel="stylesheet" type="text/css" href="styles/header.css">
    <link rel="stylesheet" type="text/css" href="styles/login.css">

</head>
<body>
    <?php
    include 'loading.php';
    include 'header.php';
    ?>
    <main>
        <!--? slider Area Start-->
        <div class="slider-area ">
            <div class="slider-active">
                <!-- Single Slider -->
                <div class="single-slider slider-height d-flex align-items-center">
                    <div class="container">
                        <div class="row">
                            <div class="col-xl-9 col-lg-9 col-md-9">
                                <div class="hero__caption">
                                    <span data-animation="fadeInLeft" data-delay=".2s" style="color: #d486d5">Discover Your Taste~</span>
                                    <h1 data-animation="fadeInLeft" data-delay=".4s">We belive good food offer great smile</h1>
                                    <p data-animation="fadeInLeft" data-delay=".6s">Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat is aute irure.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Single Slider -->
                <div class="single-slider slider-height d-flex align-items-center">
                    <div class="container">
                        <div class="row">
                            <div class="col-xl-9 col-lg-9 col-md-9">
                                <div class="hero__caption">
                                    <span data-animation="fadeInLeft" data-delay=".2s" style="color: #d486d5">Discover Your Taste</span>
                                    <h1 data-animation="fadeInLeft" data-delay=".4s">We belive good food offer great smile</h1>
                                    <p data-animation="fadeInLeft" data-delay=".6s">Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat is aute irure.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- slider Area End-->
        <!--? About Area Start -->
        <div class="about-low-area section-padding30">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6 col-md-12">
                        <div class="about-caption mb-50">
                            <!-- Section Tittle -->
                            <div class="section-tittle mb-35">
                                <span style="color: #d486d5">Discover Your Taste</span>
                                <h2>We Reccommend Good Places to Eat For Your Family!</h2>
                            </div>
                            <p>Ut enim acgsd minim veniam, quxcis nostrud exercitation ullamco laboris nisi ufsit aliquip ex ea commodo consequat is aute irure m, quis nostrud exer.</p>
                        </div>
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-10">
                                <div class="single-caption mb-20">
                                    <div class="caption-icon">
                                        <span class="flaticon-restaurant"></span>
                                    </div>
                                    <div class="caption">
                                        <p>A place that have great chef</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-10">
                                <div class="single-caption mb-20">
                                    <div class="caption-icon">
                                        <span class="flaticon-tools-and-utensils-1"></span>
                                    </div>
                                    <div class="caption">
                                        <p>A place with best OOTD and comfortable clean environment</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-10">
                                <div class="single-caption mb-20">
                                    <div class="caption-icon">
                                        <span class="flaticon-hat"></span>
                                    </div>
                                    <div class="caption">
                                        <p>A place that have good and special food</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-10">
                                <div class="single-caption mb-20">
                                    <div class="caption-icon">
                                        <span class="flaticon-restaurant"></span>
                                    </div>
                                    <div class="caption">
                                        <p>A place that have positive peoples with positive vibes around</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12">
                        <!-- about-img -->
                        <div class="about-img ">
                            <img src="https://media.istockphoto.com/photos/chinese-chef-portrait-picture-id891866834?k=6&m=891866834&s=170667a&w=0&h=QIdDZp9XqbUBOVH6ru-XsMRPIizFOOfKg2iiM7EDQjQ=" alt="chef">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- About Area End -->
        <!--? gallery Products Start -->
        <section class="gallery-area fix ">
            <!-- Gallery Top Start -->
            <div class="gallery-top section-bg pt-90 pb-40" data-background="assets/img/gallery/section_bg01.png">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="cl-xl-7 col-lg-8 col-md-10">
                            <!-- Section Tittle -->
                            <div class="section-tittle text-center mb-70">
                                <span style="color: #d486d5">We Reccommend</span>
                                <h2>Some Trendy And  Popular Places</h2>
                            </div> 
                        </div>
                    </div>
                    <div class="row justify-content-center">
                        <div class="properties__button">
                            <!--Nav Button  -->
                            <nav>                                                                         
                                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                    <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true" style="background: #d486d5"> Dessert </a>
                                    <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false" style="background: #d486d5"> Breakfast </a>
                                    <a class="nav-item nav-link" id="nav-contact-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="false" style="background: #d486d5"> Lunch </a>
                                    <a class="nav-item nav-link" id="nav-dinner-tab" data-toggle="tab" href="#nav-dinner" role="tab" aria-controls="nav-dinner" aria-selected="false" style="background: #d486d5"> Dinner </a>
                                </div>
                            </nav>
                            <!--End Nav Button  -->
                        </div>
                    </div>
                </div>
            </div>
            <!-- Gallery Top End -->
            <!-- Gallery Bottom Start -->
            <div class="container-fluid p-0">
                <!-- Nav Card -->
                <div class="tab-content" id="nav-tabContent">
                    <!-- card one -->
                    <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                        <div class="row no-gutters">
                            <div class="col-lg-5 col-md-6 col-sm-6">
                                <div class="gallery-box">
                                    <div class="single-gallery">
                                        <div class="gallery-img big-img" style="background-image: url(https://i2.wp.com/penangfoodie.com/wp-content/uploads/2020/07/100818918_1351706565020346_1753777026906456064_o.jpg?resize=1080%2C1618);"></div>
                                        <div class="g-caption">
                                            <h4>Kopi Chap Tekoh</h4>
                                            <p>Not a fan of coffee? Matcha concoction looks extremely sinful, too.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="gallery-box">
                                    <div class="single-gallery">
                                        <div class="gallery-img big-img" style="background-image: url(https://i2.wp.com/penangfoodie.com/wp-content/uploads/2020/07/100808047_164180571745137_8673707847504101376_o.jpg?resize=1080%2C1440);"></div>
                                        <div class="g-caption">
                                            <h4>De Antique</h4>
                                            <p>Just as Instagram-worthy, find various slices of cakes, tarts, and bread right here.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12">
                                <div class="row no-gutters">
                                    <div class="col-lg-12 col-md-6 col-sm-6">
                                        <div class="gallery-box">
                                            <div class="single-gallery">
                                                <div class="gallery-img smoll-img" style="background-image: url(https://i2.wp.com/penangfoodie.com/wp-content/uploads/2020/06/80802009_157255632282190_4897841766916193827_n.jpg?resize=1080%2C1080);"></div>
                                                <div class="g-caption">
                                                    <h4>JOJIE & JESS Home Based Baker</h4>
                                                    <p>JOJIE & JESS is a home-based business that sells exclusive and instagrammable treats such as macaroons, pretzels, and sugar cookies. </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-6 col-sm-6">
                                        <div class="gallery-box">
                                            <div class="single-gallery">
                                                <div class="gallery-img smoll-img" style="background-image: url(https://i1.wp.com/penangfoodie.com/wp-content/uploads/2020/06/70430519_2219759211485828_3128848263565916895_n.jpg?resize=1080%2C1080);"></div>
                                                <div class="g-caption">
                                                    <h4>The Sole Baker</h4>
                                                    <p>The baker can produce 50-100 pieces of simple cookies in a day! That includes decorating and packaging.</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Card two -->
                    <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                        <div class="row no-gutters">
                            <div class="col-lg-5 col-md-6 col-sm-6">
                                <div class="gallery-box">
                                    <div class="single-gallery">
                                        <div class="gallery-img big-img" style="background-image: url(https://i2.wp.com/penangfoodie.com/wp-content/uploads/2020/07/106423524_3421645254553098_7360406606638674396_o.jpg?resize=1080%2C1080);"></div>
                                        <div class="g-caption">
                                            <h4>Ah Lye Cozy Cafe</h4>
                                            <p>Some of its notable favourites include Maggi topped off with cheese, toasted bread with soft boiled eggs, and frothy coffee!</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="gallery-box">
                                    <div class="single-gallery">
                                        <div class="gallery-img big-img" style="background-image: url(https://i2.wp.com/penangfoodie.com/wp-content/uploads/2020/06/Foursquare-suhaimi.jpg?resize=780%2C585);"></div>
                                        <div class="g-caption">
                                            <h4>Suhaimi Cafe</h4>
                                            <p>With a menu that includes both local and international food, don’t be surprised to find Italian pasta served next to a traditional Roti Bengali with Chicken Curry.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12">
                                <div class="row no-gutters">
                                    <div class="col-lg-12 col-md-6 col-sm-6">
                                        <div class="gallery-box">
                                            <div class="single-gallery">
                                                <div class="gallery-img smoll-img" style="background-image: url(https://i2.wp.com/penangfoodie.com/wp-content/uploads/2020/06/@ariesmakan-canning.jpg?resize=768%2C960);"></div>
                                                <div class="g-caption">
                                                    <h4>Canning Dim Sum</h4>
                                                    <p>Canning Dim Sum is one of a few Dim Sum places in Malaysia that’s actually Muslim-friendly.</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-6 col-sm-6">
                                        <div class="gallery-box">
                                            <div class="single-gallery">
                                                <div class="gallery-img smoll-img" style="background-image: url(https://i0.wp.com/penangfoodie.com/wp-content/uploads/2020/06/mischievous__hodophile-daishugeok.jpg?resize=1080%2C1350);"></div>
                                                <div class="g-caption">
                                                    <h4>Dai Shu Geok Big Tree Foot</h4>
                                                    <p>Famous for their Yong Tau Fu, what makes this place so special is that they serve it with Assam Laksa and Curry Mee.</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Card three -->
                    <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">
                        <div class="row no-gutters">
                            <div class="col-lg-5 col-md-6 col-sm-6">
                                <div class="gallery-box">
                                    <div class="single-gallery">
                                        <div class="gallery-img big-img" style="background-image: url(https://i1.wp.com/penangfoodie.com/wp-content/uploads/2020/06/102412523_3156746437738556_1293998371769354077_n.jpg?resize=1080%2C1440);"></div>
                                        <div class="g-caption">
                                            <h4>Nasi Kandar</h4>
                                            <p>The Pak Cik was truly motivated to offer affordable meals to help others, especially people from the lower-income brackets. Customers will find a variety of dishes priced at RM1. </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="gallery-box">
                                    <div class="single-gallery">
                                        <div class="gallery-img big-img" style="background-image: url(https://i1.wp.com/penangfoodie.com/wp-content/uploads/2020/06/67762888_2344593955754993_6119433716457537536_o.jpg?resize=1220%2C1220);"></div>
                                        <div class="g-caption">
                                            <h4>Hidden Farm Cafe</h4>
                                            <p>The cafe scene in Penang is vast, most of us spend our weekend by going on a cafe-hopping adventure.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12">
                                <div class="row no-gutters">
                                    <div class="col-lg-12 col-md-6 col-sm-6">
                                        <div class="gallery-box">
                                            <div class="single-gallery">
                                                <div class="gallery-img smoll-img" style="background-image: url(assets/img/gallery/gallery3.png);"></div>
                                                <div class="g-caption">
                                                    <h4>Delicious Food</h4>
                                                    <p>Ut enim ad minim veniam quis nostr.</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-6 col-sm-6">
                                        <div class="gallery-box">
                                            <div class="single-gallery">
                                                <div class="gallery-img smoll-img" style="background-image: url(https://i0.wp.com/penangfoodie.com/wp-content/uploads/2020/06/c702d55f-ce55-4f6d-9e46-4fe75d3b4a74.jpg?resize=1080%2C607);"></div>
                                                <div class="g-caption">
                                                    <h4>Brown Poodle</h4>
                                                    <p>A humble cafe that churns out Asian & Western cuisine together with some local delights.</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Card Four -->
                    <div class="tab-pane fade" id="nav-dinner" role="tabpanel" aria-labelledby="nav-dinner">
                        <div class="row no-gutters">
                            <div class="col-lg-5 col-md-6 col-sm-6">
                                <div class="gallery-box">
                                    <div class="single-gallery">
                                        <div class="gallery-img big-img" style="background-image: url(https://i1.wp.com/penangfoodie.com/wp-content/uploads/2020/06/103500164_274828900295487_424240883127722586_n.jpg?resize=1080%2C1350);"></div>
                                        <div class="g-caption">
                                            <h4>Thai Mama Mee</h4>
                                            <p>They serve piping hot noodles drenched in thick, sour yet spicy Tom Yam broth and comes loaded with a wide variety of toppings.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="gallery-box">
                                    <div class="single-gallery">
                                        <div class="gallery-img big-img" style="background-image: url(https://i0.wp.com/penangfoodie.com/wp-content/uploads/2020/06/ce98e848-19a5-4f66-ad2e-c41dbe7666c4.jpg?resize=1080%2C1302);"></div>
                                        <div class="g-caption">
                                            <h4>Sugar Tang</h4>
                                            <p>From the name, you already know that Sugar Tang will be famous for its sweet treats!</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12">
                                <div class="row no-gutters">
                                    <div class="col-lg-12 col-md-6 col-sm-6">
                                        <div class="gallery-box">
                                            <div class="single-gallery">
                                                <div class="gallery-img smoll-img" style="background-image: url(https://i0.wp.com/penangfoodie.com/wp-content/uploads/2020/06/84013751_3443855685687397_7572979498442817536_o.jpg?resize=1080%2C1440);"></div>
                                                <div class="g-caption">
                                                    <h4>Passion of Kerala</h4>
                                                    <p>There’s nothing more satisfying than banana leaf rice.</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-6 col-sm-6">
                                        <div class="gallery-box">
                                            <div class="single-gallery">
                                                <div class="gallery-img smoll-img" style="background-image: url(https://i2.wp.com/penangfoodie.com/wp-content/uploads/2020/06/5M2A7286.jpg?resize=1220%2C813);"></div>
                                                <div class="g-caption">
                                                    <h4>Reve</h4>
                                                    <p>Reve is considered to be one of the best cafe openings in Penang last year</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Nav Card -->
            </div>
            <!-- Gallery Bottom End -->
        </section>
        <!-- gallery Products End -->
        <!--? About-2 Area Start -->
        <div class="about-area2 section-padding30">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6 col-md-12">
                        <!-- about-img -->
                        <div class="about-img ">
                            <img src="https://i0.wp.com/penangfoodie.com/wp-content/uploads/2020/07/IMG_9717.jpg?resize=1220%2C1013" alt="">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12">
                        <div class="about-caption mb-50">
                            <!-- Section Tittle -->
                            <div class="section-tittle mb-35">
                                <span style="color: #d486d5">About Us</span>
                                <h2>We Reccomend Good Food  For Your Family!</h2>
                            </div>
                            <p class="pera-top">Ut enim acgsd minim veniam, quxcis nostrud exercitation ullamco laboris nisi ufsit aliquip ex ea commodo consequat is aute irure m, quis nostrud exer</p>

                            <p  class="mb-65 pera-bottom">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected our, or randomised words which don't look even slightly believab If you are going to use a passage.</p>
                            <a href="about.php" class="border-btn" style="background: #d486d5">Learn More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- About-2 Area End -->
        <!--? Blog Area Start -->
        <section class="blogs-area section-padding30">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6">
                        <!-- Section Tittle -->
                        <div class="section-tittle text-center mb-70">
                            <span style="color: #d486d5">Our New Blog News</span>
                            <h2>Our Recent News</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="single-blogs mb-100">
                            <div class="blog-img">
                                <img src="https://i1.wp.com/penangfoodie.com/wp-content/uploads/2020/07/@forestcanteenbythesea-Instagram.jpg?resize=1080%2C721" alt="">
                            </div>
                            <div class="blog-cap" style="background: #d486d5">
                                <span class="color1" style="color: #fff">11am - 7am (close on Tuesday)</span>
                                <h4><a href="blog_details.html">Forest Canteen</a></h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="single-blogs mb-100">
                            <div class="blog-img">
                                <img src="https://i1.wp.com/penangfoodie.com/wp-content/uploads/2020/06/Sizzling-Suzai-yongsuan.jpg?resize=1024%2C683 alt="">
                            </div>
                            <div class="blog-cap" style="background: #d486d5">
                                <span class="color1"style="color: #fff">9am - 4am</span>
                                <h4><a href="blog_details.html">Yong Suan Coffee Shop</a></h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="single-blogs mb-100">
                            <div class="blog-img">
                                <img src="https://i1.wp.com/penangfoodie.com/wp-content/uploads/2020/07/@placewemeet-Facebook.jpg?resize=1220%2C813" alt="">
                            </div>
                            <div class="blog-cap" style="background: #d486d5">
                                <span class="color1"style="color: #fff">6pm - 11pm</span>
                                <h4><a href="blog_details.html">Place We Meet</a></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Blog Area End -->
    </main>
    <?php
            include 'footer.php';
    ?>
    <!-- Scroll Up -->
    <div id="back-top" style="background: #d486d5">
        <a title="Go to Top" href="#" > <i class="fas fa-level-up-alt"></i></a>
    </div>

    <!-- JS here -->

    <script src="./assets/js/vendor/modernizr-3.5.0.min.js"></script>
    <!-- Jquery, Popper, Bootstrap -->
    <script src="./assets/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="./assets/js/popper.min.js"></script>
    <script src="./assets/js/bootstrap.min.js"></script>
    <!-- Jquery Mobile Menu -->
    <script src="./assets/js/jquery.slicknav.min.js"></script>

    <!-- Jquery Slick , Owl-Carousel Plugins -->
    <script src="./assets/js/owl.carousel.min.js"></script>
    <script src="./assets/js/slick.min.js"></script>
    <!-- One Page, Animated-HeadLin -->
    <script src="./assets/js/wow.min.js"></script>
    <script src="./assets/js/animated.headline.js"></script>
    <script src="./assets/js/jquery.magnific-popup.js"></script>
    
    <!-- Nice-select, sticky -->
    <script src="./assets/js/jquery.nice-select.min.js"></script>
    <script src="./assets/js/jquery.sticky.js"></script>
    
    <!-- contact js -->
    <script src="./assets/js/contact.js"></script>
    <script src="./assets/js/jquery.form.js"></script>
    <script src="./assets/js/jquery.validate.min.js"></script>
    <script src="./assets/js/mail-script.js"></script>
    <script src="./assets/js/jquery.ajaxchimp.min.js"></script>
    
    <!-- Jquery Plugins, main Jquery -->	
    <script src="./assets/js/plugins.js"></script>
    <script src="./assets/js/main.js"></script>
    
    </body>
</html>