<?php
    session_start();
     if(isset($_SESSION['user_id'])){

       }
     else{
       echo '<script type="text/javascript">alert("Please login to continue!");</script>';
      echo'<meta http-equiv="refresh" content="2; url=index.php">';
      }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title> Delicates</title>
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSS here -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/slicknav.css">
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/slick.css">
    <link rel="stylesheet" href="assets/css/nice-select.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
    <link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
    <link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
    <link rel="stylesheet" type="text/css" href="styles/main_styles.css">
    <link rel="stylesheet" type="text/css" href="styles/responsive.css">
    <link rel="stylesheet" type="text/css" href="styles/header.css">
    <link rel="stylesheet" type="text/css" href="styles/login.css">
</head>
<body>
        <!--? Header Start -->
         <?php
            include 'loading.php';
            include 'header.php';
        ?>
        <!-- Header End -->
  
        <!--? Hero Start -->
        <div class="slider-area ">
            <div class="slider-height2 d-flex align-items-center">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="hero-cap hero-cap2">
                                <h2>Blog</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Hero End -->
        <!--================Blog Area =================-->
       <?php
            if (isset($_POST['blog_id'])){
            $id = $_POST['blog_id'];
                        $servername = "localhost";
                        $username = "root";
                        $password = "";
                        $dbname = "delicates";
                           
                        // Create connection
                        $conn = new mysqli($servername, $username, $password, $dbname);
                        // Check connection
                        if ($conn->connect_error) 
                            die("Connection failed: " . $conn->connect_error);
                            
                        $sql = "SELECT *FROM blogs WHERE blog_id = '$id'";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {                    
                            while($row = $result->fetch_assoc()) {
                                echo"<section class=\"blog_area single-post-area section-padding\">
                                       <div class=\"container\">
                                          <div class=\"row\">
                                             <div class=\"col-lg-8 posts-list\">
                                                <div class=\"single-post\">
                                                   <div class=\"feature-img\">
                                                      <img class=\"img-fluid\" src=\"{$row['blog_image']}\" alt=\"\">
                                                   </div>
                                                   <div class=\"blog_details\">
                                                      <h2 style=\"color: #2d2d2d;\">{$row['blog_name']}
                                                      </h2>
                                                      <p class=\"excert\">
                                                         {$row['blog_para1']}
                                                      </p>
                                                      <p>
                                                        {$row['blog_para2']}
                                                      </p>
                                                      <p>
                                                        {$row['blog_para3']}
                                                      </p>
                                                      <p>
                                                        {$row['blog_para4']}
                                                      </p>
                                                   </div>
                                                </div>
                                               </div>
                                             </div>
                                          </div>
                                    </section>";
                            }
                        }     
                        else {
                            alert("Error display blog details!");
                        }
                        $conn->close();
                        }
                        else{
                            echo'<section class="blog_area section-padding">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-lg-8 mb-5 mb-lg-0">
                                                <div class="blog_left_sidebar">';
                                                    ?>
                                                    <?php
                                                    $servername = "localhost";
                                                    $username = "root";
                                                    $password = "";
                                                    $dbname = "delicates";

                                                    // Create connection
                                                    $conn = new mysqli($servername, $username, $password, $dbname);
                                                    // Check connection
                                                    if ($conn ->connect_error) 
                                                        die("Connection failed: " . $conn->connect_error);

                                                    $sql = "SELECT * FROM blogs";
                                                    $result = $conn->query($sql);
                                                    if ($result->num_rows > 0) {

                                                        while($row = $result->fetch_assoc()) {
                                                            $id = $row['blog_id'];
                                                            echo " <article class= \"blog_item\">
                                                            <div class=\"blog_item_img\">
                                                            <img class= \"card-img rounded-0\" src=\"{$row['blog_image']}\" alt=\"\">
                                                            </div>
                                                            <div class=\"blog_details\">
                                                            <form name = \"product_details\" method=\"post\">
                                                            <a class=\"d-inline-block\" href=\"blog.php\">
                                                            <button style=\"background: #550a43;\">{$row['blog_name']}</button>
                                                            <input type=\"hidden\" name=\"blog_id\" value=\"{$id}\">
                                                            </a>
                                                            <p>{$row['blog_des']}</p>
                                                            </form>
                                                            </div>
                                                            </article>";
                                                        }
                                                    }     
                                                    else {
                                                        echo "0 results";
                                                    }
                                                    $conn->close();
                                                    ?>
                        <?php
                            echo'                      
                                        </div>
                                    </div>
                                </div>
                            </div>
                      </section>';
                        }
                        ?>
        <!--================Blog Area =================-->
  
    <?php
         include 'footer.php';
    ?>
    <!-- Scroll Up -->
    <div id="back-top" style="background: #d486d5">
        <a title="Go to Top" href="#"> <i class="fas fa-level-up-alt"></i></a>
    </div>

    <!-- JS here -->
	
    <script src="./assets/js/vendor/modernizr-3.5.0.min.js"></script>
    <!-- Jquery, Popper, Bootstrap -->
    <script src="./assets/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="./assets/js/popper.min.js"></script>
    <script src="./assets/js/bootstrap.min.js"></script>
    <!-- Jquery Mobile Menu -->
    <script src="./assets/js/jquery.slicknav.min.js"></script>

    <!-- Jquery Slick , Owl-Carousel Plugins -->
    <script src="./assets/js/owl.carousel.min.js"></script>
    <script src="./assets/js/slick.min.js"></script>
    <!-- One Page, Animated-HeadLin -->
    <script src="./assets/js/wow.min.js"></script>
    <script src="./assets/js/animated.headline.js"></script>
    
    <!-- Nice-select, sticky -->
    <script src="./assets/js/jquery.nice-select.min.js"></script>
    <script src="./assets/js/jquery.sticky.js"></script>
    <script src="./assets/js/jquery.magnific-popup.js"></script>

    <!-- contact js -->
    <script src="./assets/js/contact.js"></script>
    <script src="./assets/js/jquery.form.js"></script>
    <script src="./assets/js/jquery.validate.min.js"></script>
    <script src="./assets/js/mail-script.js"></script>
    <script src="./assets/js/jquery.ajaxchimp.min.js"></script>
    
    <!-- Jquery Plugins, main Jquery -->	
    <script src="./assets/js/plugins.js"></script>
    <script src="./assets/js/main.js"></script>
    
    </body>
</html>