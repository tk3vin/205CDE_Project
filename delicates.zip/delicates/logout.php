<?php
    session_start();
    
    if(isset($_SESSION['user_id'])){
        session_destroy();
        echo'<meta http-equiv="refresh" content="2; url=index.php">';
    }
?>